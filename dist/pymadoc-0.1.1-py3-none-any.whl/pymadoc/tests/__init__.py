"""
Test package for pyMADOC
""" 